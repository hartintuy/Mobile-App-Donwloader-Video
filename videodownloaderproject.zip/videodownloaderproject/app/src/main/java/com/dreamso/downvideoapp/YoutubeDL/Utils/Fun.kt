package com.dreamso.downvideoapp.YoutubeDL.Utils

/**
 * Created by harshithg on 17/1/18.
 */

data class Fun(var name: String, var argnames: Array<String>, var code: String)