package com.dreamso.downvideoapp.interfaces;

import com.dreamso.downvideoapp.fragments.models.YoutubeDataModel;

public interface OnItemClickListener {
    void onItemClick(YoutubeDataModel item);

}
