# video-downloader
This is a Android application which is able to download videos from Youtube, Facebook and dailymotion
